// when the package of the current app is not included it means  it is external to the project
//package myserver ;
import java.io.DataOutputStream ;
import java.io.DataInputStream ;
import java.io.FileInputStream ;
import java.io.FileOutputStream ;

import java.util.List;
import java.util.Set;
import java. util. Iterator;
import java.io.IOException ;
import java.io.ObjectInputStream;
import java.net.Socket ;
import java.net.InetSocketAddress ;
import java.io.DataInputStream ;
import java.net.ServerSocket ;
import java.util.HashMap ;
import java.util.Map ;


// redis server import for storing the map of ip and port 
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.exceptions.JedisException;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.HostAndPort;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;

// import org.redisson.Redisson ;
import org.redisson.* ;
import org.redisson.config.* ;
import org.redisson.api.* ; 

public class videoServer extends Thread {

    private ServerSocket ss;
    private  String fileName  = null;
    
    // private static HostAndPort hnp = HostAndPortUtil.getRedisServers().get(0);

    



 

    public videoServer(int port) {
        try {
            ss = new ServerSocket(port);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void run() {
        System.out.println("started") ;
        Config config = new Config();

       // config.useClusterServers().addNodeAddress("redis://50.1.1.1:6379");
	config.useSingleServer().setAddress("redis://127.0.0.1:6379");
        //RedissonClient redisson = Redisson.create(new Config() );
	RedissonClient redisson = Redisson.create(config );
	System.out.println("here");
        RListMultimap<String, String> ipMap = redisson.getListMultimap("ip1");
        ipMap.put("1234" , "vishal") ;	
	
	
	while (true) {
            try {

                Socket clientSock = ss.accept();
                fileName = null ;
                saveFile(clientSock);
                System.out.println("connection established") ;

                
                ipMap.put((((InetSocketAddress) clientSock.getRemoteSocketAddress()).getAddress()).toString().replace("/","") ,fileName) ;




    //-------------------------------------------------------

                
                // ipMap.put(fileName ,(((InetSocketAddress) clientSock.getRemoteSocketAddress()).getAddress()).toString().replace("/","") ) ;
                // portMap.put(fileName , clientSock.getPort()) ; 

                // jedis.hmset("ip", ipMap);
                // jedis.hmset("port", portMap);


                // clientSock = ss.accept();
                // sendFile(clientSock ,fileName);
                // System.out.println("sending completed \n listening") ;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void saveFile(Socket clientSock) throws IOException {
        ObjectInputStream ios  = new ObjectInputStream(clientSock.getInputStream()) ;
        //getting the fileName of the user


        try {
            fileName = (String)ios.readObject();
        } catch (ClassNotFoundException e) {
            e.printStackTrace( );

        }

        DataInputStream dis = new DataInputStream(clientSock.getInputStream());
        FileOutputStream fos = new FileOutputStream(fileName);
        byte[] buffer = new byte[10096];

        int filesize = 17682432; // Send file size in separate msg
        int read = 0;
        int totalRead = 0;
        int remaining = filesize;
        while((read = dis.read(buffer, 0, Math.min(buffer.length, remaining))) > 0) {
            totalRead += read;
            remaining -= read;
            System.out.println("read " + totalRead + " bytes.");
            fos.write(buffer, 0, read);
        }

        fos.close();
        // dis.close();

    }

    public void sendFile( Socket clientSock,String file) throws IOException {

        System.out.println("sending file") ;
        DataOutputStream dos = new DataOutputStream(clientSock.getOutputStream());
        FileInputStream fis = new FileInputStream(file);
        byte[] buffer = new byte[4096];

        while (fis.read(buffer) > 0) {
            dos.write(buffer);
        }

        fis.close();
        dos.close();
    }
    public static void main(String[] args) {
        videoServer fs = new videoServer(2900);
        System.out.println("ready  for sending the data");
        fs.run();
    }
}

